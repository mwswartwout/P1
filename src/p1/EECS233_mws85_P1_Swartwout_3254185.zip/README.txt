To run the demo: Compile and run TestProblem

To run the test cases: Compile and run P1. To switch between NumArrayList and NumLinkedList uncomment the desired
constructor and comment out the non-desired one in the beginning of the code. To test NumSet uncomment the 
constructor and array declarations, comment out the other constructors at the beginning of the code. Then uncomment 
the constructor and the calls for intersect, union, and print at the end of the code.